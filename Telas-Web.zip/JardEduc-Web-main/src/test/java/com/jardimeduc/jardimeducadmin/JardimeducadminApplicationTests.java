package com.jardimeduc.jardimeducadmin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JardimeducadminApplicationTests {

	@Test
	void contextLoads() {
	}

}
