package com.jardimeduc.jardimeducadmin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JardimeducadminApplication {

	public static void main(String[] args) {
		SpringApplication.run(JardimeducadminApplication.class, args);
	}

}
